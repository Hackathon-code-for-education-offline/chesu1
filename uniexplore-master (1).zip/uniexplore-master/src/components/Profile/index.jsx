import { Flex } from 'antd';
import React from 'react';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { fetchUsers } from '../../redux/userReducer';


import './index.css'

const Profile = () => {

  const {id} = useParams()

  const users = useSelector(state => state.users.users)

  const dispatch = useDispatch()

  useEffect(() => {
    dispatch(fetchUsers())
  }, [dispatch])

  const user = users.find(item => item._id === id)
  console.log(user)

  return (
    <div>
      <div>
        <h1 style={{textAlign: 'center', padding: '50px'}}>Ваш профиль</h1>
      </div>
      <div style={{display: 'flex', width: '60%', margin: 'auto', justifyContent: 'space-between'}}>
      {/* <div style={{width: '300px', height: '400px', background: 'gray', borderRadius: '20px'}}>
          
          </div> */}
       <img src="https://avatars.githubusercontent.com/u/98719246?v=4" alt="" />
        <Flex style={{width: '300px'}} wrap='wrap' gap='10px'>
          <div className='user-sh'>Имя: <div className='user_info'>{user?.name}</div></div>
          <div className='user-sh'>Фамилия: <div className='user_info'>{user?.lastName}</div></div>
          <div className='user-sh'>Почта: <div className='user_info'>{user?.email}</div></div>
          <div className='user-sh'>Логин: <div className='user_info'>{user?.login}</div></div>
        </Flex>
      </div>
    </div>
  );
};

export default Profile;